# DABI Companion — Android starter scaffold

This is an initial native Android project scaffold for DABI. It is **not a finished voice assistant and not an APK**.

## Current scaffold
- Kotlin Android app shell
- User-triggered foreground service with a persistent notification
- Runtime microphone and notification permission request
- Android project configuration

## Not implemented yet
- The custom “Hey DABI” wake-word model/detector
- Speech-to-command pipeline
- App launching by recognized command
- Accessibility Service for user-enabled screen interaction
- Secure connection to the existing DABI web app
- Build/signing/installation and testing on a physical phone

## Build
Open this folder in Android Studio with a compatible Android SDK installed, sync Gradle, then build an APK. Test on a real device and review all permissions before enabling anything.

## Android limitations
Android imposes microphone foreground-service, battery, background-start, and notification restrictions. A foreground service does not itself detect a wake word. Continuous wake-word detection needs a real detector/model and device testing. `QUERY_ALL_PACKAGES` is highly restricted by Google Play policy and should be removed or replaced with package visibility declarations before a Play Store release.
